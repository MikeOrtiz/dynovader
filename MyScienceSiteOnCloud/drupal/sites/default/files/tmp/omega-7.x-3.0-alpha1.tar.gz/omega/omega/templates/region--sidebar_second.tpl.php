<?php if ($content): ?>
  <aside<?php print $attributes; ?>>
    <?php print $content; ?>
  </aside>
<?php endif; ?>
