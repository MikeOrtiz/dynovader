<?php if ($wrapper): ?><div<?php print $wrapper_attributes; ?>><?php endif; ?>  
  <div<?php print $attributes; ?>>
    <?php print $content; ?>
  </div>
<?php if ($wrapper): ?></div><?php endif; ?>