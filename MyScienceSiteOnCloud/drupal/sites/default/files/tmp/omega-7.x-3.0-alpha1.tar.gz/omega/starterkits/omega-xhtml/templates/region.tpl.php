<?php if (!empty($content)): ?>
  <div<?php print $attributes; ?>>
    <?php print $content; ?>
  </div>
<?php endif; ?>